package controllers;

import models.Audit;
import utils.FileHandler;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AuditController {
	  private static final String AUDITS_FILE = "data/audits.txt";

	    public void addAudit(Audit audit) {
	        FileHandler.writeToFile(AUDITS_FILE, audit.getId() + "," + audit.getOrganizationId() + "," + audit.getAuditDate() + "," + audit.getAuditDate());
	    }

	    public List<Audit> getAudits() {
	        List<Audit> audits = new ArrayList<>();
	        for (String line : FileHandler.readFromFile(AUDITS_FILE)) {
	            String[] parts = line.split(",");
	            audits.add(new Audit(parts[0], parts[1], parts[2], new Date(parts[3])));
	        }
	        return audits;
	    }
}
