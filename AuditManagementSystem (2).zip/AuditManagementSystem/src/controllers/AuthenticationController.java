package controllers;

import utils.FileHandler;

public class AuthenticationController {
	  private static final String USERS_FILE = "data/users.txt";

	    public boolean authenticate(String email, String password) {
	        for (String line : FileHandler.readFromFile(USERS_FILE)) {
	            String[] parts = line.split(",");
	            if (parts[0].equals(email) && parts[1].equals(password)) {
	                return true;
	            }
	        }
	        return false;
	    }

	    public void registerUser(String email, String password, String role) {
	        FileHandler.writeToFile(USERS_FILE, email + "," + password + "," + role);
	    }
}
