package models;

import java.util.List;
import java.util.ArrayList;

public class Organization {
	 private String id;
	    private String name;
	    private List<Site> sites;
	    private List<Process> processes;

	    public Organization(String parts, String name) {
	        this.id = parts;
	        this.name = name;
	        this.sites = new ArrayList<>();
	        this.processes = new ArrayList<>();
	    }

	    // Getters and setters
	    public String getId() { return id; }
	    public String getName() { return name; }
	    public List<Site> getSites() { return sites; }
	    public List<Process> getProcesses() { return processes; }

}
