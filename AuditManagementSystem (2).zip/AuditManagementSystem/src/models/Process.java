package models;

public class Process {
	 private String id;
	    private String name;
	    private String organizationId;

	    public Process(String parts, String name, String parts2) {
	        this.id = parts;
	        this.name = name;
	        this.organizationId = parts2;}
	    public String getId() { 
	        return id; 
	    }

	    public void setId(String id) { 
	        this.id = id; 
	    }

	    public String getName() { 
	        return name; 
	    }

	    public void setName(String name) { 
	        this.name = name; 
	    }

	    public String getOrganizationId() { 
	        return organizationId; 
	    }
	    public void setOrganizationId(String organizationId) { 
	    	this.organizationId = organizationId; 
	    }
}
