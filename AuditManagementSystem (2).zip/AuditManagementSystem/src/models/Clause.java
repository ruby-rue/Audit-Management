package models;

import java.util.List;
import java.util.ArrayList;

public class Clause {
	 private int id;
	    private String code;
	    private String description;
	    private int standardId;
		private String name;
		private List<Clause> clauses;

	    public Clause(int id, String code, String description, int standardId) {
	        this.id = id;
	        this.code = code;
	        this.description = description;
	        this.standardId = standardId;
	    }
	    public Clause(String string, String string2, String string3) {
			// TODO Auto-generated constructor stub
		}
		public int getId() { 
	        return id; 
	    }

	    public void setId(int id) { 
	        this.id = id; 
	    }

	    public String getName() { 
	        return getName(); 
	    }

	    public void setName(String name) { 
	        this.name = name; 
	    }

	    public List<Clause> getClauses() { 
	        return getClauses(); 
	    }

	    public void setClauses(List<Clause> clauses) { 
	        this.clauses = clauses; 
	    }

	    public void addClause(Clause clause) {
	        this.clauses.add(clause);
	    }
		public int getStandardId() {
			// TODO Auto-generated method stub
			return 0;
		}
		}

