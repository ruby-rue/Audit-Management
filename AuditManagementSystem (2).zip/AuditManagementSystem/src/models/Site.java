package models;

import java.util.List;
import java.util.ArrayList;

public class Site {
	 private int id;
	    private String name;
	    private List<Site> sites;
	    private List<Process> processes;

	    public void Organization(int id, String name) {
	        this.id = id;
	        this.name = name;
	        this.sites = new ArrayList<>();
	        this.processes = new ArrayList<>();
	    }

	    // Getters and setters
	    public int getId() { return id; }
	    public String getName() { return name; }
	    public List<Site> getSites() { return sites; }
	    public List<Process> getProcesses() { return processes; }

		public int getOrganizationId() {
			// TODO Auto-generated method stub
			return 0;
		}

}
